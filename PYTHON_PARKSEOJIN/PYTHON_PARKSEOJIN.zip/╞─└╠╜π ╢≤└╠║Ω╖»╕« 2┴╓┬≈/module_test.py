#!/usr/bin/env python
# coding: utf-8

# In[4]:


def add(num1, num2):
    return num1 + num2

